const filteredAdmissionsAboveAvg = [
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Arbor Health-Morton General",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.2804,
    "long": 46.5557
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Sunnyside Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -120.0067,
    "long": 46.3225
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-15",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Astria Toppenish Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -120.3171,
    "long": 46.3708
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Behavioral Hospital",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.296,
    "long": 47.4877
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -120.6608,
    "long": 47.5945
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Cascade Val Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.1189,
    "long": 48.1889
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-15",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia Basin Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-03",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-10",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-15",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-17",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Columbia County Health System",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.5468,
    "long": 47.3146
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Central WA Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -120.321,
    "long": 47.4066
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Confluence Health Wenatchee Val Hospital",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -120.3231,
    "long": 47.4335
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "Coulee Medical Center",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.007,
    "long": 47.9422
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "East Adams Rural Healthcare",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -118.3719,
    "long": 47.1212
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-01",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-02",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-03",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-04",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-05",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-06",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-07",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-08",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-09",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-10",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-11",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-12",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-13",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-14",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-15",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-16",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-17",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-18",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-19",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-20",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-21",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-22",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-23",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-24",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-25",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-26",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-27",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-28",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-29",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-09-30",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-01",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-02",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-03",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-04",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-05",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-06",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-07",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-08",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-09",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-10",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-11",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-12",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-13",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-14",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-15",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-16",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-17",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-18",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-19",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-20",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-21",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-22",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-23",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-24",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-25",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-26",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-27",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-28",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-29",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-30",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Kirkland",
    "ds": "2023-10-31",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-01",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-02",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-03",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-04",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-05",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-06",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-07",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-08",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-09",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-10",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-11",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-12",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-13",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-14",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-15",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-16",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-17",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-18",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-19",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-20",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-21",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-22",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-23",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-24",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-25",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-26",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-27",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-28",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-29",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-09-30",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-01",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-02",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-03",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-04",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-05",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-06",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-07",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-08",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-09",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-10",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-11",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-12",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-13",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-14",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-15",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-16",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-17",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-18",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-19",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-20",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-21",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-22",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-23",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-24",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-25",
    "above_avg": 1
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-26",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-27",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-28",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-29",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-30",
    "above_avg": 0
  },
  {
    "hospital_name": "Evergreen Health Monroe",
    "ds": "2023-10-31",
    "above_avg": 0
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Kirkland",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.2043,
    "long": 47.7191
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-02",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-09",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-16",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-14",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-21",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-28",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Fairfax Behavioral Health Monroe",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.8634
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-22",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-27",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-29",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Ferry Cty Mem Hosp",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -118.7314,
    "long": 48.653
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Forks Comm Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -124.3926,
    "long": 47.9462
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Grays Harbor Comm Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -123.8472,
    "long": 46.9792
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Inland Northwest Behavioral Health",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.4143,
    "long": 47.6515
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Island Hosp",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.6157,
    "long": 48.5019
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Jefferson Healthcare",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.7893,
    "long": 48.106
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kadlec Reg Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.282,
    "long": 46.2813
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kaiser Permanente Central Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.3121,
    "long": 47.62
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kindred Hospital Seattle",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.3286,
    "long": 47.6119
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Kittitas Valley Healthcare",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -120.5379,
    "long": 46.9871
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-14",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-15",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-22",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Klickitat Val Community Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -120.8111,
    "long": 45.8202
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Lake Chelan Comm Hosp and Clinics",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -120.0096,
    "long": 47.845
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Legacy Salmon Creek Medical Center",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.6482,
    "long": 45.721
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-06",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lincoln Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -118.1454,
    "long": 47.6579
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Counseling Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.2813,
    "long": 46.2831
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Lourdes Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -119.0954,
    "long": 46.235
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mason Gen Hosp and Family of Clinics",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -123.1144,
    "long": 47.2259
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "Mid Val Hosp",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -119.5465,
    "long": 48.3966
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Capital Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.9518,
    "long": 47.0427
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Mary Bridge Childrens Hospital and Health Center",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.4546,
    "long": 47.2597
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "MultiCare Tacoma Gen Hosp - Allenmore",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.4527,
    "long": 47.2593
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Auburn Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.229,
    "long": 47.3089
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 1,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 1,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Covington Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.1037,
    "long": 47.3591
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Deaconess Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.4234,
    "long": 47.652
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Good Samaritan Hosp",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.2895,
    "long": 47.1792
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Multicare Valley Hospital",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -117.2355,
    "long": 47.6708
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Navos",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.3666,
    "long": 47.5347
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "Newport Hospital and Health Services",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.0492,
    "long": 48.1824
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-06",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "North Val Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.4387,
    "long": 48.707
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-21",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-22",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-27",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-28",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Ocean Beach Hospital and Medical Clinics",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -124.0426,
    "long": 46.3114
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-24",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-01",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-27",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-28",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-29",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Odessa Memorial Healthcare Center",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -118.6825,
    "long": 47.3312
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Olympic Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -123.415,
    "long": 48.1156
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-29",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Othello Comm Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.1553,
    "long": 46.8304
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "Overlake Hosp Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.1872,
    "long": 47.6205
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Peace Island Medical Center",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -123.0279,
    "long": 48.5294
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH Southwest MD Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.5807,
    "long": 45.6244
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St John Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.9417,
    "long": 46.1307
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH St Joseph Medical Center",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.4732,
    "long": 48.7733
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "PH United General Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.2763,
    "long": 48.4961
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prosser Memorial Hospital",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -119.764,
    "long": 46.2081
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Centralia Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.9883,
    "long": 46.7115
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Holy Family Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.4067,
    "long": 47.7098
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-22",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-29",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Mt Carmel Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.8927,
    "long": 48.5407
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Rgnl Med Ctr Everett",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.2057,
    "long": 47.9999
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov Sacred Heart Med Ctr and Childrens Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.413,
    "long": 47.6489
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-22",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-29",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Josephs Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.7108,
    "long": 48.2778
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Mary Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -118.3432,
    "long": 46.0622
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Prov St Peter Hosp",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.8474,
    "long": 47.0529
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-06",
    "above_avg": 1,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Providence St. Lukes Rehabilitation Medical Center",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -117.4091,
    "long": 47.649
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Pullman Reg Hosp",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -117.1698,
    "long": 46.7125
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-02",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-03",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-09",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-14",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-15",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-21",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-22",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-27",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-28",
    "above_avg": 1,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Quincy Val Med Center",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.8682,
    "long": 47.2309
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Rainier Springsiatric Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.6422,
    "long": 45.7142
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Samaritan Healthcare",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -119.2652,
    "long": 47.1282
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-29",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-06",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Cancer Care Alliance",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.3298,
    "long": 47.6266
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Seattle Childrens Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.2821,
    "long": 47.6626
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Shriners Hospital for Children-Spokane Orthopedics Specialists",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -117.4257,
    "long": 47.6509
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skagit Valley Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.324,
    "long": 48.4179
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-06",
    "above_avg": 1,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Skyline Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -121.4705,
    "long": 45.7224
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-15",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-22",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-13",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-27",
    "above_avg": 1,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Smokey Point Behav Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.1795,
    "long": 48.1388
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "Snoqualmie Val Hosp District",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -121.8857,
    "long": 47.5127
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-05",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "South Sound Behaviroal Hosptial",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.8276,
    "long": 47.0426
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anne Medical Center",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.3432,
    "long": 47.4574
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Anthony Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.6136,
    "long": 47.363
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Clare Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.502,
    "long": 47.1543
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Elizabeth Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -121.9878,
    "long": 47.2092
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Francis Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.3274,
    "long": 47.2927
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Joseph Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.4482,
    "long": 47.246
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "St. Michael Med Ctr Bremerton and Silverdale",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.6754,
    "long": 47.6555
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-15",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-22",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-28",
    "above_avg": 1,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Summit Pacific Med Center",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -123.393,
    "long": 47.0069
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Edmonds",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.3344,
    "long": 47.8032
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish Issaquah",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.0219,
    "long": 47.5358
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Swedish-Cherry Hill",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.3106,
    "long": 47.6077
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-03",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-08",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-13",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-14",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Three Rivers Hospital",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.7826,
    "long": 48.1062
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Tri State Mem Hosp",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -117.0544,
    "long": 46.4029
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "Trios Health",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -119.1192,
    "long": 46.1992
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 1,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine Harborview Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.324,
    "long": 47.6039
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine University Of WA Med Ctr and Northwest",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "UW Medicine Valley Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.3093,
    "long": 47.6509
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 1,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 1,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 1,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Virginia Mason Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -122.328,
    "long": 47.6088
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-01",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-06",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-07",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-14",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-15",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-18",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-20",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-21",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-22",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-27",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-28",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-29",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Wellfound Behavioral Health Hospital",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -122.4807,
    "long": 47.2418
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-01",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-02",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-03",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-04",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-05",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-06",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-07",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-08",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-09",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-10",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-11",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-12",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-13",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-14",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-15",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-16",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-17",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-18",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-19",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-20",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-21",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-22",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-23",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-24",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-25",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-26",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-27",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-28",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-29",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-09-30",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-01",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-02",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-03",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-04",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-05",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-06",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-07",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-08",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-09",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-10",
    "above_avg": 1
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-11",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-12",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-13",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-14",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-15",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-16",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-17",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-18",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-19",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-20",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-21",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-22",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-23",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-24",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-25",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-26",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-27",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-28",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-29",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-30",
    "above_avg": 0
  },
  {
    "hospital_name": "Whidbey Health",
    "ds": "2023-10-31",
    "above_avg": 0
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-26",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-19",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-25",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-26",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-27",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Whitman Hosp and Med Ctr",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -117.376,
    "long": 46.8689
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-05",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-11",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-12",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-15",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-17",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-18",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-19",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-20",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-21",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-22",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-24",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-25",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-27",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-29",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-02",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-10",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-16",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-17",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-23",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-24",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-30",
    "above_avg": 1,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Willapa Harbor Hosp",
    "ds": "2023-10-31",
    "above_avg": 0,
    "lat": -123.8123,
    "long": 46.6628
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-01",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-02",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-03",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-04",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-05",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-06",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-07",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-08",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-09",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-10",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-11",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-12",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-13",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-14",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-15",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-16",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-17",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-18",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-19",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-20",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-21",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-22",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-23",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-24",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-25",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-26",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-27",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-28",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-29",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-09-30",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-01",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-02",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-03",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-04",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-05",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-06",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-07",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-08",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-09",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-10",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-11",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-12",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-13",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-14",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-15",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-16",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-17",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-18",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-19",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-20",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-21",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-22",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-23",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-24",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-25",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-26",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-27",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-28",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-29",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-30",
    "above_avg": 0,
    "lat": -120.5479,
    "long": 46.5937
  },
  {
    "hospital_name": "Yakima Valley Memorial Hospital",
    "ds": "2023-10-31",
    "above_avg": 1,
    "lat": -120.5479,
    "long": 46.5937
  }
] ;
